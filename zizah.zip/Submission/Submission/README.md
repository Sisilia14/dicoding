#setup environment

pip install pandas matplotlib seaborn streamlit

#run streamlit

streamlit run dashboaard.py